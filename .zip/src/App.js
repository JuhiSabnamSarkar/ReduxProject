import './App.css';
import Posts from './features/posts/Posts';

function App() {
  return (
    <div className="App">
      <>
        <Posts />
      </>
    </div>
  );
}

export default App;
